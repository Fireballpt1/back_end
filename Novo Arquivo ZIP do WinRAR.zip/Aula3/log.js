// var log ={
//             info: function (info) {
//                 console.log('Info:' + info);
//              },
//              warning: function (warning) {
//                  console.log('Warning:' + warning);
//              },
//              error: function (error) {
//                  console.log('Error:' + error);
//              },
// };

// var log2 ={
//     update: function(info) {
//         console.log('Update:' + info);}
//     // },
//     // warning: function(warning) {
//     //     console.log('Warning:' + warning);
//     // },
//     // error: function(error) {
//     //     console.log('Error:' + error);
//     // },
// };

// module.exports.log= log;
// module.exports.log2= log2;
